package org.transmartproject.pipeline.loader

class TransmartException extends Exception{


//custome exception for transmart loader

	TransmartException(String s){
		super(s);
	}
}
